class Card {
  constructor(shape, number) {
    this.shape = shape;
    this.number = number;
  }
}

module.exports = Card;
